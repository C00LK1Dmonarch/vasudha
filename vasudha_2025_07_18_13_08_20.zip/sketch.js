let video;
let label = "waiting...";
let classifier;
let modelURL = 'https://teachablemachine.withgoogle.com/models/WmorNIpii/';

let beep;
let beeping = false;
let audioStarted = false;

let distressDetectedTime = null;
let delayTime = 5000; // 5 seconds delay

function preload() {
  classifier = ml5.imageClassifier(modelURL + 'model.json');
}

function setup() {
  createCanvas(640, 520);
  video = createCapture(VIDEO);
  video.hide();

  beep = new p5.Oscillator('sine');
  beep.amp(0);
  beep.start();

  userStartAudio();
  classifyVideo();
}

function mousePressed() {
  if (!audioStarted) {
    userStartAudio();
    audioStarted = true;
  }
}

function classifyVideo() {
  classifier.classify(video, gotResults);
}

function gotResults(error, results) {
  if (error) {
    console.error(error);
    return;
  }
  label = results[0].label;

  if (label === "Scared/nervous" && audioStarted) {
    if (!distressDetectedTime) {
      distressDetectedTime = millis();
    } else if (!beeping && millis() - distressDetectedTime >= delayTime) {
      startBeepBoopCycles(10);
      distressDetectedTime = null;
    }
  } else {
    distressDetectedTime = null;
  }

  classifyVideo();
}

function startBeepBoopCycles(cycles) {
  beeping = true;
  let count = 0;

  function playBeepBoop() {
    if (count >= cycles) {
      beeping = false;
      return;
    }

    beep.freq(800);
    beep.amp(0.5, 0.05);
    setTimeout(() => {
      beep.amp(0, 0.05);

      setTimeout(() => {
        beep.freq(300);
        beep.amp(0.5, 0.05);
        setTimeout(() => {
          beep.amp(0, 0.05);
          count++;
          setTimeout(playBeepBoop, 500); // 500ms pause before next cycle
        }, 300);  // Boop duration

      }, 200);  // Gap between Beep and Boop

    }, 300);  // Beep duration
  }

  playBeepBoop();
}

function draw() {
  background(0);
  image(video, 0, 0);
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text(label, width / 2, height - 16);

  if (!audioStarted) {
    fill(255, 0, 0);
    textSize(24);
    text("Tap to enable sound", width / 2, height / 2);
  }
}
